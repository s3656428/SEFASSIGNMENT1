package resources;

import java.util.Scanner;

import driver.HRSystem;

public class Report {

	private String reportDate;
	
	public static void createReport(){
        int courseNum = 0;
       
        System.out.println("Create Report");
       
        while(true) {
          System.out.println("-------------");
          System.out.println("Enter 'cancel' to cancel the operation");
          System.out.println("Please enter a course ID: ");
       
          Scanner input = new Scanner(System.in);
          String command = input.nextLine();
       
          if(command.equals("cancel")) {
              input.close();
              return;
          }
         
          boolean courseFound = false;
          for(int i = 0; i < HRSystem.getCourseList().size(); i++) {
       
            if(HRSystem.getCourseList().get(i).getCourseCode().equals(command)) {
                courseNum = i;
                courseFound = true;
                break; 
            }
           
          }
       
          if(courseFound == true) {
            break;
          }else {
            System.out.println("No course matching tha id was found");
            continue;
          }
       
        }
       
        System.out.printf("%-22s %s\n", "Course Code:", HRSystem.getCourseList().get(courseNum).getCourseCode());
        System.out.printf("%-22s %s\n", "Course Name:", HRSystem.getCourseList().get(courseNum).getCourseName());
        System.out.printf("%-22s $%.2f\n", "Budget:", HRSystem.getCourseList().get(courseNum).getBudget());
 
    }
}
