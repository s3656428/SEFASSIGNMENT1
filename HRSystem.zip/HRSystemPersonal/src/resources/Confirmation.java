package resources;

import java.util.Scanner;

import users.*;

public class Confirmation {

	private String startTime;
	private String endTime;
	private String location;
	private double payRateperHour;
	
	public void confirmAvailability(User coord){
		
		System.out.println(coord);
		System.out.println("Are you available? '1' for available, anything for deny");
		Scanner scan = new Scanner(System.in);
		String choose = scan.nextLine();
		if(choose.equals("1")) {
			System.out.println("Confirmation sent to " + coord.getFirstName() + " " +
					coord.getLastName() + " at " + coord.getEmail());
			
			
		}else {
			notifyUnavailability(coord);
		}
		
		scan.close();
	
	}
	
	public void notifyUnavailability(User coord){
		System.out.println(coord.getFirstName() + " " + coord.getLastName() + " has been notified of unavailability at " + coord.getEmail());
	}
}
