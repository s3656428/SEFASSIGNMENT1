package users;

import driver.HRSystem;

public class CourseCoord extends User {

	public CourseCoord(String userID,  String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

		
	public static void viewCourses(){
        int courseNum = 0;
        int nameWidth = 0;
       
        if(HRSystem.getCourseList().size() == 0) {
            System.out.printf("\nThere are currently no courses\n");
            return;
        }
       
        //Get max width of names
        for(int i = 0; i < HRSystem.getCourseList().size(); i++) {
           
            if(HRSystem.getCourseList().get(i).getCourseName().length() > nameWidth) {
               
                nameWidth = HRSystem.getCourseList().get(i).getCourseName().length();
            }
                   
        }
       
        System.out.printf("%-15s|%-25s|%-12s|%-10s\n", "Course Code", "Course Name", "Start Date", "End Date" );
       
        for(int i = 0; i < 65; i++) {
            if(i == 64) {
                System.out.println("-");
            }else {
                System.out.print("-");
            }
        }
       
        for(int i = 0; i < HRSystem.getCourseList().size(); i++) {
           
            System.out.printf("%-15s|%-25s|%-12s|%-10s\n",
                    HRSystem.getCourseList().get(i).getCourseCode(), HRSystem.getCourseList().get(i).getCourseName(), HRSystem.getCourseList().get(i).getStartDate(), HRSystem.getCourseList().get(i).getEndDate() );
               
        }
       
       
    }
}