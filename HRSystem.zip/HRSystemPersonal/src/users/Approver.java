package users;

import java.util.Scanner;

import resources.*;

public class Approver extends User {

	public Approver(String userID,  String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

	public void viewRequest(String[] request) {
		System.out.println(request);
		System.out.println("Would you like to accept or deny the request? '1' for accept, anything for deny");
		Scanner scan = new Scanner(System.in);
		String choose = scan.nextLine();
		if(choose.equals("1")) {
			acceptRequest(request);
		}else {
			denyRequest(request);
		}
		
		scan.close();
	}

	public void acceptRequest(String[] request) {
		System.out.println("Request Accepted");
		//delete request from list
	}

	public void denyRequest(String[] request) {
		System.out.println("Request Denied");
		//delete request from list
		//contactCasual("cc for reason");
	}

	public double viewBudget() {
		return Admin.getBudget();
	}

	public String viewStaffProfile(CasualStaffProfile[] staff, int num) {
		return staff[num].getStaffDetails();
	}
	
	public void contactCC(User cc){
		Scanner scan = new Scanner(System.in);
		System.out.println("What would you like to say to "+ cc.getFirstName() + " " + cc.getLastName() + "?");
		String message = scan.nextLine();
		
		System.out.println(cc.getFirstName() + " " + cc.getLastName() + " has been sent the message at " + cc.getEmail());
		System.out.println("Message: " + message);
		scan.close();
		//send email
	}
	
	public void contactCasual(User staff){
		Scanner scan = new Scanner(System.in);
		System.out.println("What would you like to say to "+ staff.getFirstName() + " " + staff.getLastName() + "?");
		String message = scan.nextLine();
		
		System.out.println(staff.getFirstName() + " " + staff.getLastName() + " has been sent the message at " + staff.getEmail());
		System.out.println("Message: " + message);
		scan.close();
		//send email
	}
}
