package driver;

import java.io.*;
import java.util.*;
import users.*;
import resources.*;



	public class HRSystem {
		
		static ArrayList<User> user = new ArrayList<User>();
		static ArrayList<Admin> admin = new ArrayList<Admin>();
		static ArrayList<CourseCoord> cc = new ArrayList<CourseCoord>();
		static ArrayList<Approver> approver = new ArrayList<Approver>();
		static ArrayList<Casual> casual = new ArrayList<Casual>();
		static ArrayList<Course> courseList = new ArrayList<Course>();
		
		public static void main(String[] args) {
			HRSystem system = new HRSystem();
			
			
			initiateLists();
			
			//for register()
			Scanner scan = new Scanner(System.in);
			System.out.println("HR SYSTEM MENU");
			System.out.println("1.Register\n2.Log In\n3.Cancel");
			System.out.print("Please enter 1, 2 or 3: ");
			String input = scan.nextLine();
			
			if (input.equals("1")){
				system.register();
				system.login();
			}else if (input.equals("2"))
			{
				system.login();
			}else if (input.equals("3"))
			{
				System.out.print("Exited out of HR System.");
				System.exit(0);
			}
			scan.close();
		}

	private static void initiateLists() {
		
		String[] resourceList = new String[50];
	
		String resFileName = "resources.txt";
		Scanner inputStream1 = null;
		
			try {
				inputStream1 = new Scanner(new File(resFileName));
		} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int i = 0;
				
			String rDetail1;

			while (inputStream1.hasNextLine()) {
						rDetail1 = inputStream1.nextLine();
						resourceList[i] = new String(rDetail1);
						i++;
						
					}
				
				System.out.println("Resources have been loaded from " + resFileName);

		inputStream1.close();
		

		
		String casFileName = "users.txt";
		Scanner inputStream2 = null;

	
			try {
				inputStream2 = new Scanner(new File(casFileName));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		

			String userID;
			String password;
			String email;
			String firstName;
			String lastName; 
			String occupation;

			while (inputStream2.hasNextLine()) {
					
					userID = inputStream2.nextLine();
					password = inputStream2.nextLine();
					email= inputStream2.nextLine();
					firstName = inputStream2.nextLine();
					lastName = inputStream2.nextLine();
					occupation = inputStream2.nextLine();
					
					
					if(occupation.equals("casual")) {
						user.add(new User(userID, password, email, firstName, lastName, "Casual Staff"));
						casual.add(new Casual(userID, password, email, firstName, lastName, "Casual Staff"));
					}else if(occupation.equals("coord"))  {
						user.add(new User(userID, password, email, firstName, lastName, "Course Coordinator"));
						cc.add(new CourseCoord(userID, password, email, firstName, lastName, "Course Coordinator"));
					}else if(occupation.equals("approve"))  {
						user.add(new User(userID, password, email, firstName, lastName, "Approver"));
						approver.add(new Approver(userID, password, email, firstName, lastName, "Approver"));
					}else if(occupation.equals("admin")){
						user.add(new User(userID, password, email, firstName, lastName, "Admin"));
						admin.add(new Admin(userID, password, email, firstName, lastName, "Admin"));
					}
						
						inputStream2.nextLine();
			}
		
				System.out.println("Resources have been loaded from " + casFileName + "\n");

			inputStream2.close();


	}




	public void register() {
		
		// user sets up account
		Scanner scan = new Scanner(System.in);
		System.out.println("REGISTER\n");
		System.out.println("What is your occupation? Enter\n1 for Casual Staff \n2 for Course Coordinator \n3 for Approver \n4 for Admin");
		String occupation = scan.nextLine();
		System.out.print("Choose user ID: ");
		String userID = scan.nextLine();
		System.out.print("Choose password: ");
		String password = scan.nextLine();
		System.out.print("Enter email: ");
		String email = scan.nextLine();
		System.out.print("Enter first name: ");
		String firstName = scan.nextLine();
		System.out.print("Enter last name: ");
		String lastName = scan.nextLine();
		
		
		user.add(new User(userID, password, email, firstName, lastName, occupation));
		user.toString();
		
		scan.close();
	}
	
	public boolean login() {
		// user enters username and pw
		// returns true or false
		System.out.println("login");
		return false;
		
		
	}
	public void accessAdminMenu() {
		// if occupation is "Administrator",redirect user to admin menu
		
		
	}

	public void accessCCMenu() {
		// if occupation is "Course Coordinator"",redirect user to course coord menu
		// menu
	}

	public void accessApproveMenu() {
		// if occupation is "Approver",redirect user to approver menu
	}

	public void accessCasualMenu() {
		// if occupation is "Casual Staff",redirect user to casual staff menu
	}
	 
	public static ArrayList<Course> getCourseList(){
	        return courseList;
	    }
	
	
	
}
