package resources;

public class Confirmation {

	private String startTime;
	private String endTime;
	private String location;
	private double payRateperHour;
	
	public boolean confirmAvailability(){
		return false;
	}
	
	public void notifyUnavailability(){
		if(!confirmAvailability()){
			//notify CC
		}
	}
}
