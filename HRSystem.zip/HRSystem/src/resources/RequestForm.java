package resources;

public class RequestForm {

	private String firstName;
	private String lastName;
	private String resource;
	private String startTime;
	private String endTime;
	private String activity;
	private double payRatePerHour;
	
	public void requestStaff(){
		//enters number of staff needed
		//loops for x number of staff for course coord to enter name
	}
	
	public void requestResources(){
		//enters number of resources needed
		//loops for x number of resources
	}
	
	public void submit(){
	//display request for approver	
	}
}
