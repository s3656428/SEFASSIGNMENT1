package resources;

public class Course {
	
	private String courseName;
	private String courseCode;
	private double budget;
	private String startDate;
	private String endDate;
	
	public Course(String courseName, String courseCode, double budget, String startDate, String endDate){
		this.courseName = courseName;
		this.courseCode = courseCode;
		this.budget = budget;
		this.startDate = startDate;
		this.endDate = endDate;
	}
}
