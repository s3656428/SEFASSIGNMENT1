package resources;

public class Course {

	private String courseName;
	private String courseCode;
	private double budget;
	private String startDate;
	private String endDate;

	public Course(String courseName, String courseCode, double budget, String startDate, String endDate) {
		this.courseName = courseName;
		this.courseCode = courseCode;
		this.budget = budget;
		this.startDate = startDate;
		this.endDate = endDate;

		System.out.printf("COURSE INFO \n%s\n", this);

	}
	
	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public double getBudget() {
		return budget;
	}

	public void setBudget(double budget) {
		this.budget = budget;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String toString() {
		return String.format(
				"Course name: %s\n" + "Course Code: %s\n" + "Budget: %s\n" + "Start Date: %s\n" + "End Date: %s\n",
				courseName, courseCode, budget, startDate, endDate);
	}
}
