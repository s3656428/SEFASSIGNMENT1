package resources;

public class Report {

	private String reportDate;
	
	public void createReport(){
		
	}
}
