package resources;

public class Timetable {

	private String course;
	private String classType;
	private String location;
	private String startTime;
	private String endTime;
	
	public Timetable(String course, String classType, String location, String startTime,String endTime)
	{
		this.course = course;
		this.classType = classType;
		this.location = location;
		this.startTime = startTime;
		this.endTime = endTime;
	}

}


