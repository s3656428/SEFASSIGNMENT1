package resources;

public class Timetable {

	private String classType;
	private String location;
	private String startTime;
	private String endTime;
}
