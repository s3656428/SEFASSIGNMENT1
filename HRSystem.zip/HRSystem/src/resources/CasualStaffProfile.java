package resources;

public class CasualStaffProfile {

	
	private String firstName;
	private String lastName;
	private String workingHours;
	private String activities;
	private String eduLevel;
	
	
	public CasualStaffProfile(String firstName, String lastName, String workingHours, 
			String activities, String eduLevel) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.workingHours = workingHours;
		this.activities = activities;
		this.eduLevel = eduLevel;
	}
	
	public String getStaffDetails() {
		String staffLine1 = firstName + " ";
		String staffLine2 = lastName + "\n";
		String staffLine3 = workingHours + " ";
		String staffLine4 = activities + "\n";
		String staffLine5 = eduLevel + "\n";
		
		String staffDetails = staffLine1 + staffLine2 + staffLine3 + staffLine4 + staffLine5;
		return staffDetails;
	}
	
	public String getFirstName() {
		
		return firstName;
	}
	
	public String getLastName() {
		
		return lastName;
	}
	
	public String getActivities() {
		return activities;
	}
}
