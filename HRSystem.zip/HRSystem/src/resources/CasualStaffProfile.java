package resources;

public class CasualStaffProfile {

	private String firstName;
	private String lastName;
	private String workingHours;
	private String activities;
	private String eduLevel;
	
	
}
