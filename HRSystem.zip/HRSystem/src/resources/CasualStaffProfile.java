package resources;

public class CasualStaffProfile {

	private String firstName;
	private String lastName;
	private String workingHours;
	private String activities;
	private String eduLevel;

	public CasualStaffProfile(String cFirstName, String cLastName, String cWorkingHours, String cActivities,
			String cEdulevel) {
		firstName = cFirstName;
		lastName = cLastName;
		workingHours = cWorkingHours;
		activities = cActivities;
		eduLevel = cEdulevel;
	}

}
