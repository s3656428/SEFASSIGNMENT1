package driver;

import users.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import resources.*;


public class HRSystem {

	ArrayList<User> user = new ArrayList<User>();
	
	public static void main(String[] args) {
		HRSystem system = new HRSystem();
		
		//for register()
		Scanner scan = new Scanner(System.in);
		System.out.println("HR SYSTEM MENU");
		System.out.println("1.Register\n2.Log In\n3.Cancel");
		System.out.print("Please enter 1, 2 or 3: ");
		String input = scan.nextLine();
		
		if (input.equals("1")){
			system.register();
			system.login();
		}else if (input.equals("2"))
		{
			system.login();
		}else if (input.equals("3"))
		{
			System.out.print("Exited out of HR System.");
			System.exit(0);
		}
		
		
		
		//for requestResource() in RequestForm
		String[] resourceList = new String[50];
		
		String fileName = "resources.txt";
		Scanner inputStream = null;
		
			try {
				inputStream = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int i = 0;
				
			String detail1;

			while (inputStream.hasNextLine()) {
						detail1 = inputStream.nextLine();
						resourceList[i] = new String(detail1);
						i++;
						
					}
				
				System.out.println("Resources have been loaded from " + fileName);

		inputStream.close();
		RequestForm.requestResources(resourceList);
	}

	public void register() {
		// user sets up account
		Scanner scan = new Scanner(System.in);
		System.out.println("REGISTER\n");
		System.out.print("Choose user ID: ");
		String userID = scan.nextLine();
		System.out.print("Choose password: ");
		String password = scan.nextLine();
		System.out.print("Enter email: ");
		String email = scan.nextLine();
		System.out.print("Enter first name: ");
		String firstName = scan.nextLine();
		System.out.print("Enter last name: ");
		String lastName = scan.nextLine();
		System.out.print("Enter occupation: ");
		String occupation = scan.nextLine();
		
		user.add(new User(userID, password, email, firstName, lastName, occupation));
		user.toString();
	}

	public boolean login() {
		// user enters username and pw
		// returns true or false
		return false;
		
		
	}

	public void accessAdminMenu() {
		// if occupation is "Administrator",redirect user to admin menu
	}

	public void accessCCMenu() {
		// if occupation is "Course Coordinator"",redirect user to course coord menu
		// menu
	}

	public void accessApproveMenu() {
		// if occupation is "Approver",redirect user to approver menu
	}

	public void accessCasualMenu() {
		// if occupation is "Casual Staff",redirect user to casual staff menu
	}

}
