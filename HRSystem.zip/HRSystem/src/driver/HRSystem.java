package driver;

import users.User;
import java.util.*;

public class HRSystem {

	public static void main(String[] args) {

		
	}

	public void register() {
		//user sets up username and pw
	}

	public boolean login() {
		//user enters username and pw
		//returns true or false
		return false;
	}


	public void accessAdminMenu() {
		//if occupation is "Administrator",redirect user to admin menu
	}

	public void accessCCMenu() {
		//if occupation is "Course Coordinator",redirect user to course coord menu
	}

	public void accessApproveMenu() {
		//if occupation is "Approver",redirect user to approver menu
	}

	public void accessCasualMenu() {
		//if occupation is "Casual Staff",redirect user to casual staff menu
	}

}
