package driver;

import users.User;
import java.util.*;

public class HRSystem {

	public static void main(String[] args) {

		
	}

	public void register() {
		//user sets up username and pw
	}

	public boolean login() {
		//user enters username and pw
		//returns true or false
		return false;
	}


	public void accessAdminMenu() {
		//if username begins with "ad",redirect user to admin menu
	}

	public void accessCCMenu() {
		//if username begins with "cc",redirect user to course coord menu
	}

	public void accessApproveMenu() {
		//if username begins with "ap",redirect user to approver menu
	}

	public void accessCasualMenu() {
		//if username begins with "cs",redirect user to casual staff menu
	}

}
