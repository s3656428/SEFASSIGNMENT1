package users;

public class Admin extends User {

	public Admin(String userID, String firstName, String lastName) {
		super(userID, firstName, lastName);
	}

		
	public void setupSemester(){
		//list course, course coord, approver
	}
	
	public void inputTimetable(){
		
	
	}
	
	public void viewStaffList(){
		//reads from external database/text file
	}
	
	public void viewActivities(){
		
	}
}
