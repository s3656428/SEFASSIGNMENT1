package users;

import resources.*;
import java.util.*;

import driver.HRSystem;

public class Admin extends User {

	private String courseName;
	private String courseCode;
	private static double budget;
	private String startDate;
	private String endDate;
	private double salary;

	public Admin(String userID, String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

	public void createSemester() {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter course name: ");
		courseName = scan.nextLine();
		System.out.print("Enter course code: ");
		courseCode = scan.nextLine();
		System.out.print("Enter budget: ");
		budget = scan.nextDouble();
		System.out.print("Enter start date: ");
		startDate = scan.nextLine();
		System.out.print("Enter end date: ");
		endDate = scan.nextLine();

		Course course = new Course(courseName, courseCode, budget, startDate, endDate);

		scan.close();
	}

	public void inputTimetable(Course course) {

		System.out.println("Course " + course.getCourseName() + " will start at \n" + course.getStartDate()
				+ " and end at " + course.getEndDate());

	}

	public static void viewStaffList(ArrayList<Casual> casual) {

		Iterator<Casual> itr = casual.iterator();
		// iterator for going through arraylist
		while (itr.hasNext()) {
			Casual cas = (Casual) itr.next();
			System.out.println(cas.getFirstName() + " " + cas.getLastName());
			// prints the first and last name
		}

	}

	public void viewActivities(CasualStaffProfile[] staff) {
		int i = 0;
		while (staff[i].getFirstName() != "") {
			System.out.print(staff[i].getFirstName() + " " + staff[i].getLastName() + " has ");
			if (staff[i].getActivities().equals("")) {
				System.out.print("no activities.\n");
			} else {
				System.out.print(staff[i].getActivities());
				i++;
			}
		}
	}

	public static double getBudget() {
		return budget;
	}
}
