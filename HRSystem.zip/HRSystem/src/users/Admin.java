package users;

import resources.Course;
import java.util.*;

public class Admin extends User {

	static Scanner scan = new Scanner(System.in);
	
	
	public Admin(String userID, String firstName, String lastName, String email) {
		super(userID, firstName, lastName, email);
	}


	public  void setupSemester(){
		//list course, course coord, approver

		 
	}
	public void inputTimetable(){
		
	
	}
	
	public  void viewStaffList(){
		//reads from external database/text file
	}
	
	public  void viewActivities(){
		
	}
}
