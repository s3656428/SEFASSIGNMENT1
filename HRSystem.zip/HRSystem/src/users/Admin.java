package users;

import resources.Course;
import java.util.*;

public class Admin extends User {

	static Scanner scan = new Scanner(System.in);
	
	
	public Admin(String userID,  String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}


	public  void setupSemester(){
		//list course, course coord, approver

		 
	}
	public void inputTimetable(){
		
	
	}
	
	public  void viewStaffList(){
		//reads from external database/text file
	}
	
	public  void viewActivities(){
		
	}
}
