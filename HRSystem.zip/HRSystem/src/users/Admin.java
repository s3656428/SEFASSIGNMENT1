package users;

import resources.Course;
import resources.CasualStaffProfile;
import java.util.*;

public class Admin extends User {
		
	private String courseName;
	private String courseCode;
	private double budget;
	private String startDate;
	private String endDate;
	private double salary;

	public Admin(String userID, String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

	public void createSemester() {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter course name: ");
		courseName = scan.nextLine();
		System.out.print("Enter course code: ");
		courseCode = scan.nextLine();
		System.out.print("Enter budget: ");
		budget = scan.nextDouble();
		System.out.print("Enter start date: ");
		startDate = scan.nextLine();
		System.out.print("Enter end date: ");
		endDate = scan.nextLine();
		
		Course course = new Course(courseName, courseCode, budget, startDate, endDate);

	}

	public void inputTimetable() {

	}

	public void viewStaffList() {
		// reads from external database/text file
		CasualStaffProfile staff[] = new CasualStaffProfile[5];
		staff[0] = new CasualStaffProfile("Fred", "One", "Friday, 11:30-13:30", "Lecture", "Bachelor");
		staff[1] = new CasualStaffProfile("James", "Two", "Thursday, 12:30-13:30", "Tutorial", "PhD");
		staff[2] = new CasualStaffProfile("Alice", "Three", "Wednesday, 12:30-2:30", "Lecture", "Masters");
		staff[3] = new CasualStaffProfile("Nadia", "Four", "Tuesday, 13:30-15:30", "Lab", "Doctorate");
		staff[4] = new CasualStaffProfile("Ahmed", "Five", "Monday, 09:30-11:30", "Tutorial", "Bachelor");

		for (int i = 0; i < 5; i++) {
			System.out.println(staff[i]);
		}
	}

	public void viewActivities() {

	}
}
