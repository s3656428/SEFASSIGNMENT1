package users;

public class Casual extends User {

	private String eduLevel;
	
	public Casual(String userID, String firstName, String lastName) {
		super(userID, firstName, lastName);
	}

	public void viewEmail(){
		
	}
	
	public void confirmAvailability(){
		
	}
	
	
}
