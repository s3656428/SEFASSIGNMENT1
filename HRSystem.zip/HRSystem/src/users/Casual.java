package users;
 
import java.util.Scanner;
 
public class Casual extends User {
 
    private String eduLevel;
 
    public Casual(String userID,  String password, String email, String firstName, String lastName, String occupation) {
        super(userID, password, email, firstName, lastName, occupation);
    }
 
    public void viewEmail(User staff) {
       
        System.out.println("Viewing emails from: " + staff.getEmail());
        //direct to email
    }
 
    public void confirmAvailability(User coord) {
       
        System.out.println(coord);
        System.out.println("Are you available? '1' for available, anything for deny");
        Scanner scan = new Scanner(System.in);
        String choose = scan.nextLine();
        if(choose.equals("1")) {
            System.out.println("Confirmation sent to " + coord.getFirstName() + " " + coord.getLastName() + " at " + coord.getEmail());
        }
        scan.close();
    }
   
    public void notifyCC(User cc){
        Scanner scan = new Scanner(System.in);
        System.out.println("What would you like to say to "+ cc.getFirstName() + " " + cc.getLastName() + "?");
        String message = scan.nextLine();
       
        System.out.println(cc.getFirstName() + " " + cc.getLastName() + " has been sent the message at " + cc.getEmail());
        System.out.println("Message: " + message);
        scan.close();
    }
 
}