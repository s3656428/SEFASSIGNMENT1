package users;

public class Casual extends User {

	private String eduLevel;

	public Casual(String userID, String firstName, String lastName, String email) {
		super(userID, firstName, lastName, email);
	}

	public void viewEmail() {

	}

	public void confirmAvailability() {

	}

}
