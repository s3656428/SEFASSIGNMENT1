package users;

public class Casual extends User {

	private String eduLevel;

	public Casual(String userID,  String password, String email, String firstName, String lastName) {
		super(userID, password, email, firstName, lastName);
	}

	public void viewEmail() {

	}

	public void confirmAvailability() {

	}

}
