package users;

public class User {

	private String userID;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private String occupation;

	public User(String userID,  String password, String email, String firstName, String lastName){
		this.userID = userID;
		this.password = password;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
	};
	

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLastName() {
		return lastName;
	}


	public String getFirstName() {
		return firstName;
	}

	public String getEmail() {
		return email;
	}
	
	public String getOccupation() {
		return occupation;
	}

}
