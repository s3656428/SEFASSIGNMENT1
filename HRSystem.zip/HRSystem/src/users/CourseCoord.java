package users;

public class CourseCoord extends User {

	public CourseCoord(String userID,  String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

		
	public void viewCourses(){
		
	}
		
	public void request(){
		//creates request form object
	}
}
