package users;

public class CourseCoord extends User {

	public CourseCoord(String userID, String firstName, String lastName) {
		super(userID, firstName, lastName);
	}

		
	public void viewCourses(){
		
	}
		
	
}
