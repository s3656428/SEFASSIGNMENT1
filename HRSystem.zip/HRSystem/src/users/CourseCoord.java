package users;

public class CourseCoord extends User {

	public CourseCoord(String userID, String firstName, String lastName, String email) {
		super(userID, firstName, lastName, email);
	}

		
	public void viewCourses(){
		
	}
		
	
}
