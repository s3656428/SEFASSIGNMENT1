package users;

public class CourseCoord extends User {

	public CourseCoord(String userID,  String password, String email, String firstName, String lastName) {
		super(userID, password, email, firstName, lastName);
	}

		
	public void viewCourses(){
		
	}
		
	
}
