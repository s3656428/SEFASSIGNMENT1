package users;

public class Approver extends User {

	public Approver(String userID, String firstName, String lastName) {
		super(userID, firstName, lastName);
	}

		
	public void viewRequest(){
		
	}
	
	public void acceptRequest(){
		
	}
	
	public void denyRequest(){
		
	}
	
	public void viewBudget(){
		
	}
	
	public void viewStaffProfile(){
		
	}
}
