package users;

public class Approver extends User {

	public Approver(String userID, String firstName, String lastName, String email) {
		super(userID, firstName, lastName, email);
	}

	public void viewRequest() {

	}

	public void acceptRequest() {

	}

	public void denyRequest() {

	}

	public void viewBudget() {

	}

	public void viewStaffProfile() {

	}
}
