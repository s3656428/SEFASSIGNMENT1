package users;

public class Approver extends User {

	public Approver(String userID,  String password, String email, String firstName, String lastName, String occupation) {
		super(userID, password, email, firstName, lastName, occupation);
	}

	public void viewRequest() {

	}

	public void acceptRequest() {

	}

	public void denyRequest() {

	}

	public void viewBudget() {
		
	}

	public void viewStaffProfile() {

	}
}
